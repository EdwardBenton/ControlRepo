#!/bin/bash

# Define the key-value pairs
key1="value1"
key2="value2"

# Output the fact in JSON format
echo "{"
echo "\"structured\": {"
echo "\"key1\": \"$key1\","
echo "\"key2\": \"$key2\""
echo "}"
echo "}"